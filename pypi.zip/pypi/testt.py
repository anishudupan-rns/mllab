import sklearn
import importlib

libdirs=dir(sklearn)
target=["accuracy_score","train_test_split","DecisionTreeClassifier","plot_tree","classification_report", "confusion_matrix","cross_val_score","GaussianNB","KMeans","PCA","StandardScaler"]

for j in libdirs:
    try:
        dirs=importlib.import_module(f"sklearn.{j}")
        for k in target:
            if hasattr(dirs,k):
                print(f"from sklearn.{j} import {k}")
    except Exception:
        pass